from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base

# Создание базового класса моделей
Base = declarative_base()

# Определение модели таблицы
class DB_Scripts(Base):
    __tablename__ = 'scripts'
    script_id = Column(Integer, primary_key=True)
    script_text = Column(String)
    author = Column(String)
    created_ts = Column(String)


Base.metadata.create_all(bind=engine)